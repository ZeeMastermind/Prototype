#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "Ticket.h"
#include <QDebug>
#include <ctime>
#include <QFile>
#include <vector>
#include <fstream>
#include <string>

using namespace std;

namespace Ui {
class MainWindow;
}




class MainWindow : public QMainWindow
{
    Q_OBJECT
private:
    void getTime();
    void getFieldData();
    void genTicketID();
    void loadTickets();
    int selectTNumber();
    string currentTicket;
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void on_submit_clicked();

    void on_comboBox_highlighted(int index);

    void on_open_clicked();

    void on_addnote_clicked();

private:
    Ui::MainWindow *ui;
    string customerName;
    string ticketID;
    string creationDate;
    string serialNumber;
    string modelNumber;
    bool isOpen;
    string note;
    int tNumber;
    vector<Ticket*> ticketList;
    int maxTickets;
    int ticketCount;
    string comment;
};

#endif // MAINWINDOW_H
