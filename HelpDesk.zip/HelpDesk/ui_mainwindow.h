/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.5.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPlainTextEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QAction *actionImportTicket;
    QAction *actionEdit_Ticket;
    QWidget *centralWidget;
    QPushButton *submit;
    QLabel *title;
    QLabel *label;
    QLabel *label_2;
    QLineEdit *nameEdit;
    QLineEdit *modelEdit;
    QTextEdit *noteEdit;
    QLineEdit *serialEdit;
    QLabel *label_3;
    QLabel *label_4;
    QComboBox *comboBox;
    QTextBrowser *textBrowser;
    QLabel *label_5;
    QLabel *label_6;
    QLabel *label_7;
    QLineEdit *ticketEdit;
    QPushButton *open;
    QPushButton *addnote;
    QPlainTextEdit *newNoteBox;
    QMenuBar *menuBar;
    QMenu *File;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(538, 482);
        actionImportTicket = new QAction(MainWindow);
        actionImportTicket->setObjectName(QStringLiteral("actionImportTicket"));
        actionEdit_Ticket = new QAction(MainWindow);
        actionEdit_Ticket->setObjectName(QStringLiteral("actionEdit_Ticket"));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        submit = new QPushButton(centralWidget);
        submit->setObjectName(QStringLiteral("submit"));
        submit->setGeometry(QRect(50, 170, 121, 41));
        title = new QLabel(centralWidget);
        title->setObjectName(QStringLiteral("title"));
        title->setGeometry(QRect(210, 20, 101, 31));
        QFont font;
        font.setPointSize(12);
        font.setBold(true);
        font.setWeight(75);
        title->setFont(font);
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(30, 80, 71, 16));
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(30, 110, 61, 16));
        nameEdit = new QLineEdit(centralWidget);
        nameEdit->setObjectName(QStringLiteral("nameEdit"));
        nameEdit->setGeometry(QRect(80, 80, 120, 20));
        modelEdit = new QLineEdit(centralWidget);
        modelEdit->setObjectName(QStringLiteral("modelEdit"));
        modelEdit->setGeometry(QRect(80, 110, 120, 20));
        noteEdit = new QTextEdit(centralWidget);
        noteEdit->setObjectName(QStringLiteral("noteEdit"));
        noteEdit->setGeometry(QRect(250, 80, 261, 131));
        serialEdit = new QLineEdit(centralWidget);
        serialEdit->setObjectName(QStringLiteral("serialEdit"));
        serialEdit->setGeometry(QRect(80, 140, 120, 20));
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(30, 140, 47, 13));
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(340, 50, 71, 20));
        comboBox = new QComboBox(centralWidget);
        comboBox->setObjectName(QStringLiteral("comboBox"));
        comboBox->setGeometry(QRect(120, 250, 121, 22));
        textBrowser = new QTextBrowser(centralWidget);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(250, 250, 261, 151));
        label_5 = new QLabel(centralWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setGeometry(QRect(200, 220, 131, 21));
        label_5->setFont(font);
        label_6 = new QLabel(centralWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setGeometry(QRect(30, 250, 71, 16));
        label_7 = new QLabel(centralWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setGeometry(QRect(30, 290, 81, 16));
        ticketEdit = new QLineEdit(centralWidget);
        ticketEdit->setObjectName(QStringLiteral("ticketEdit"));
        ticketEdit->setGeometry(QRect(110, 290, 41, 20));
        open = new QPushButton(centralWidget);
        open->setObjectName(QStringLiteral("open"));
        open->setGeometry(QRect(170, 290, 75, 23));
        addnote = new QPushButton(centralWidget);
        addnote->setObjectName(QStringLiteral("addnote"));
        addnote->setGeometry(QRect(160, 380, 75, 23));
        newNoteBox = new QPlainTextEdit(centralWidget);
        newNoteBox->setObjectName(QStringLiteral("newNoteBox"));
        newNoteBox->setGeometry(QRect(30, 320, 211, 51));
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 538, 21));
        File = new QMenu(menuBar);
        File->setObjectName(QStringLiteral("File"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(File->menuAction());
        File->addAction(actionImportTicket);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        actionImportTicket->setText(QApplication::translate("MainWindow", "Import...", 0));
        actionEdit_Ticket->setText(QApplication::translate("MainWindow", "Edit Ticket", 0));
        submit->setText(QApplication::translate("MainWindow", "Submit Ticket", 0));
        title->setText(QApplication::translate("MainWindow", "New Ticket", 0));
        label->setText(QApplication::translate("MainWindow", "Name", 0));
        label_2->setText(QApplication::translate("MainWindow", "Model #", 0));
        label_3->setText(QApplication::translate("MainWindow", "Serial #", 0));
        label_4->setText(QApplication::translate("MainWindow", "Initial Note", 0));
        comboBox->setCurrentText(QString());
        label_5->setText(QApplication::translate("MainWindow", "Ticket Display", 0));
        label_6->setText(QApplication::translate("MainWindow", "Recent Tickets", 0));
        label_7->setText(QApplication::translate("MainWindow", "Ticket Number:", 0));
        open->setText(QApplication::translate("MainWindow", "Open", 0));
        addnote->setText(QApplication::translate("MainWindow", "Add Note", 0));
        File->setTitle(QApplication::translate("MainWindow", "File", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
