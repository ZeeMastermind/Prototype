#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow){


    ui->setupUi(this);

    maxTickets = 100;
    ticketCount = 0;
    currentTicket = "-1";

    creationDate = "";
    customerName = "";
    ticketID = "";
    modelNumber = "";
    serialNumber = "";

    tNumber = selectTNumber();
    cout << "tNumber: " << tNumber << endl;
    loadTickets();
}

MainWindow::~MainWindow(){
    delete ui;
    for(unsigned int i = 0; i < ticketList.size();i++)
        delete ticketList[i];
}

int MainWindow::selectTNumber(){
    int t = 0;

    ifstream tStream;
    tStream.open("ticket_0.txt");
    string tTemp;
    bool blank = tStream.is_open();
    while (blank)
    {
        t += 1;
        cout << t << endl;
        tStream.close();
        //cout << "Still in whileLoop" << endl;
        tTemp = "ticket_";
        //cout << tTemp << endl;

        ostringstream convert;
        convert << t;

        tTemp += convert.str();


        //tTemp += t;


        //cout << tTemp << endl;
        tTemp += ".txt";
        cout << tTemp << endl;

        tStream.open(tTemp.c_str());
        //cout << "still here..." << endl;
        //cout << "t: " << t << endl;
        if (!tStream.is_open())
        {
            //cout << "Not open!" << endl;
            blank = false;
        }

    }

    tStream.close();


    return t;
}

void MainWindow::on_submit_clicked(){

    getFieldData(); //get the information from the text fields

    //TODO: make sure all fields are properly filled out
        QString temp = ui->noteEdit->toPlainText();
        note = temp.toStdString();

    // Check you can still create tickets
    if(ticketCount < maxTickets){

         //add a new ticket to the vector

         ticketList.push_back(new Ticket(customerName, ticketID, creationDate, serialNumber, modelNumber, true, note));

         //if the list is not empty save the latest file to be added into vector
          if(!ticketList.empty())
                ticketList[ticketCount]->saveToFile();

          ticketCount++;

          ui->comboBox->addItem(QString::fromStdString(ticketID));
     }
}

void MainWindow::loadTickets(){

}

void MainWindow::getFieldData(){

    getTime();  //gets current system time

    //gets information from line edit
    customerName = ui->nameEdit->text().toStdString();

    modelNumber = ui->modelEdit->text().toStdString();

    serialNumber = ui->serialEdit->text().toStdString();

    genTicketID(); //gets next ticket Number
}

void MainWindow::genTicketID(){
    //converts ticket number to string than increments ticket number
    ostringstream convert;
    convert << tNumber;

    ticketID = convert.str();
    tNumber++;

}

void MainWindow::getTime(){
    time_t _tm =time(NULL );

    struct tm * curtime = localtime ( &_tm );
    creationDate = asctime(curtime);

}

void MainWindow::on_comboBox_highlighted(int index)
{
    string temp;
    temp = ticketList[index]->viewTicket();
    ui->textBrowser->setText( QString::fromStdString(temp) );
    currentTicket = ticketList[index]->getTicketID();
}

void MainWindow::on_open_clicked()
{
    string ticketNum = ui->ticketEdit->text().toStdString();
    fstream ticketStream;
    string filename = "ticket_" + ticketNum + ".txt";
    ticketStream.open(filename.c_str());
    if (ticketStream.is_open())
    {
        currentTicket = ticketNum;
        Note blah;
        Ticket readTicket("","","","","",false,blah); //dummy ticket
        readTicket.readFromFile(filename.c_str());
        string tempA = readTicket.viewTicket();
        ui->textBrowser->setText(QString::fromStdString(tempA));
    }
    else
    {
        ui->textBrowser->setText(QString("Ticket does not exist."));
    }
    ticketStream.close();
};

void MainWindow::on_addnote_clicked()
{
    cout << "addnote clicked!" << endl;
    cout << currentTicket << endl;
    if (currentTicket != "-1")
    {
        string filename = "ticket_" + currentTicket + ".txt";
        Note blah;
        Ticket readTicket("","","","","",false,blah); //dummy ticket
        readTicket.readFromFile(filename.c_str());
        Note newNote;
        newNote.note = ui->newNoteBox->toPlainText().toStdString();

        time_t _tm =time(NULL );
        struct tm * curtime = localtime ( &_tm );

        newNote.date = asctime(curtime);

        readTicket.addNote(newNote);

        string tempA = readTicket.viewTicket();
        ui->textBrowser->setText(QString::fromStdString(tempA));

        readTicket.saveToFile();

    }
    else
    {
        ui->textBrowser->setText(QString("No ticket selected."));
    }
};
